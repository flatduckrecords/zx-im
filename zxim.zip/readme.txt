ZXIM
====

Simple 2 person messenger program for the Spectranet.

1 person runs the host program, the other person connects with the client program

The person running the client will need to know the IP address of the host.

The person using the client ends the chat by typing BYE


